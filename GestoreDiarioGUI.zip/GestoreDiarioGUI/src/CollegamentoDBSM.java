import java.sql.*;
import java.util.*;
import java.time.LocalDate;
import java.sql.Date;
/**
 *
 * @author Fabio
 */
public class CollegamentoDBSM { //01
    public GestoreDiarioGUI applicazione;
    String stringaDiConnessione;
    
    public CollegamentoDBSM(GestoreDiarioGUI applicazione){
        this.applicazione = applicazione;
        stringaDiConnessione = "jdbc:mysql://" +applicazione.parametriConfigurazione.ipServerDBSM + 
                            ":" + applicazione.parametriConfigurazione.portaServerDBSM +"/" + 
                            applicazione.parametriConfigurazione.nomeDBSM; //02
    }
    
    public List<ReportDiabete> queryReportDiabete(String email, LocalDate dataInizio, LocalDate dataFine){ //03
        List<ReportDiabete> listaDiRitorno = new ArrayList();
        try(Connection connection = DriverManager.getConnection(stringaDiConnessione, applicazione.parametriConfigurazione.userDBSM,
                                    applicazione.parametriConfigurazione.passwordDBSM); //04
            PreparedStatement result = connection.prepareStatement(
                    "SELECT data_report, ora_report, glicemia, insulina, evento"
                    + " from reportdiabete where email = ? AND data_report "
                    + " BETWEEN '"+ dataInizio+"' AND '"+ dataFine+"' order by data_report desc;");    
            )
        {
            result.setString(1, email);
            ResultSet resultset = result.executeQuery();
            
            while(resultset.next()){
                listaDiRitorno.add(new ReportDiabete( 
                        resultset.getDate("data_report").toLocalDate(),
                        resultset.getString("ora_report"), 
                        resultset.getInt("glicemia"),
                        resultset.getInt("insulina"), 
                        resultset.getString("evento")));
            }
            
        }
        catch(SQLException ex){
            System.out.println("connessione fallita: " + ex.getMessage());
            return null;
            }
        return listaDiRitorno; 
        }
    
    public boolean inserisciInDB(ReportDiabete reportDiabete, String email){ //05
        try(Connection connection = DriverManager.getConnection(stringaDiConnessione, applicazione.parametriConfigurazione.userDBSM,
                                    applicazione.parametriConfigurazione.passwordDBSM); //04
            PreparedStatement inserimento = connection.prepareStatement(
                    "INSERT INTO `"+applicazione.parametriConfigurazione.nomeDBSM+"`.`reportdiabete` "
                    + "(`email`, `data_report`, `ora_report`, `glicemia`, `insulina`, `evento`)"
                    + " VALUES (?, ?, ?, ?, ?, ?);");    
            )
        {
            
            Date data = Date.valueOf(reportDiabete.getData());
            inserimento.setString(1, email);
            inserimento.setDate(2, data);
            inserimento.setString(3, reportDiabete.getOra());
            inserimento.setInt(4, reportDiabete.getGlicemia());
            inserimento.setInt(5, reportDiabete.getInsulina());
            inserimento.setString(6, reportDiabete.getEvento());
            if(inserimento.executeUpdate()>0)
                return true;
        }
        catch(SQLException ex){
            System.out.println("connessione fallita " + ex.getMessage());
        }
        return false;
    }
    
    public boolean cancellaDaDB(ReportDiabete reportDiabete, String email){//06
        try(Connection connection = DriverManager.getConnection(stringaDiConnessione, applicazione.parametriConfigurazione.userDBSM,
                                    applicazione.parametriConfigurazione.passwordDBSM);//04
            PreparedStatement eleminazione = connection.prepareStatement(
                    "DELETE FROM `reportdiabete` "
                    +" WHERE `email`= ? and`data_report`=? and`ora_report`= ?;");    
            )
        {
            
            Date data = Date.valueOf(reportDiabete.data);
            eleminazione.setString(1, email);
            eleminazione.setDate(2, data);
            eleminazione.setString(3, reportDiabete.ora);
            if(eleminazione.executeUpdate()>0)
                return true;
        }
        catch(SQLException ex){
            System.out.println("connessione fallita " + ex.getMessage());
            }
        return false;
    }
    
    public double contaValoriInRange(String email, int inferiore, int superiore, LocalDate dataInizio, LocalDate dataFine){ //07
        double ret = -1;
        try(Connection connection = DriverManager.getConnection(stringaDiConnessione, applicazione.parametriConfigurazione.userDBSM,
                                    applicazione.parametriConfigurazione.passwordDBSM);//04
            PreparedStatement conta = connection.prepareStatement(
                    "SELECT COUNT(*) FROM reportdiabete WHERE (glicemia BETWEEN ? AND ?) AND "
                            + "(data_report BETWEEN ? AND ?) AND email = ?");    
            )
        {
            
            Date data_da = Date.valueOf(dataInizio);
            Date data_a = Date.valueOf(dataFine);
            conta.setInt(1, inferiore);
            conta.setInt(2, superiore);
            conta.setDate(3, data_da);
            conta.setDate(4, data_a);
            conta.setString(5, email);
            ResultSet rs = conta.executeQuery();
            if(rs.next())
            ret = rs.getDouble(1);
            
        }
        catch(SQLException ex){
            System.out.println("connessione fallita " + ex.getMessage());
        }
        return ret;
    }
}

/*
    01 CollegamentoDBSM è la classe che si occupa di fare da ponte fra l'applicazione
    e il database, i suoi metodoti vengono chiamati dalla classe principale GestoreDiarioGUI
    
    02 stringaDiConnessione è la stringa che permette al metodo getConnection di 
    DriverManager di identificare il database con cui effettuare la connessione.
    La stringa è creata concatenando i parametri di configurazione estratti dalla 
    classe ParametriConfigurazione di cui troviamo un riferimento in GestoreDiarioGUI
    a cui accediamo tramite il riferimento applicazione.

    03 queryReportDiabete si occupa di tornare all'interno di una lista di ReportDiabete
    tutte le entrate nel database che corrispondono alla mail che prende in ingresso e
    che hanno data fra le date passate come argomenti

    04 oltre a stringaDiConnessione al metodo getConnection di DriverManager vengono 
    passati i valori del nome dello user del database e la password che possiamo 
    prendere da ParametriConfigurazione grazie al riferimento in GestoreDiarioGUI
    a cui accediamo tramite il riferimento applicazione.

    05 inserisciInDB si occupa di inserire un nuovo record nel database, prende in 
    ingresso un oggetto di topo ReportDiabete da cui estrarre i valori tramite
    i metodo di get della classe stessa, prende inoltre in ingresso la email 
    relativa all'utente che fa l'inserimento. Il metodo ritorna true in caso di
    successo, false altrimenti

    06 cancellaDaDB si occupa di cancellare un record esistente dal database, 
    prende in ingresso gli stessi valorei di inserisciInDB e anche in questo caso
    il metodo ritorna true in caso di successo, false altrimenti.
    
    07 contaValoriInRange si occupa di ritornare il numero di un particolare set di
    occorrenze nel database che rientrano in un periodo temporale indicato dalle due 
    date che prende in ingresso il metodo e che presentano dei valori di glicemia
    compresi fra due indicatori presi anch'essi in ingresso. Inoltre il metodo 
    riceve il valore di email per separare i record dei vari utenti. Il metodo 
    ritorna il numero di occorrenze cercate, ritorna -1 in caso di errore
*/