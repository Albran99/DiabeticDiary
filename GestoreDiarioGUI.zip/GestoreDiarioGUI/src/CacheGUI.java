import java.io.*;
import java.time.LocalDate;
/**
 *
 * @author Fabio
 */
public class CacheGUI { //01
    public GestoreDiarioGUI applicazione;
    
    public CacheGUI(GestoreDiarioGUI applicazione){
        this.applicazione = applicazione;
    }
    
    public boolean caricaDaCache(){    //02  
        try(FileInputStream fin = new FileInputStream("file:../../cacheGestoreDiarioGUI.bin");
                ObjectInputStream oin = new ObjectInputStream(fin);
            ){  //03
            applicazione.emailInput.setText((String)oin.readObject());
            applicazione.daDatePicker.setValue((LocalDate)oin.readObject());
            applicazione.aDatePicker.setValue((LocalDate)oin.readObject());
            applicazione.dataInput.setValue((LocalDate)oin.readObject());
            applicazione.choiceBoxOra.setValue((String)oin.readObject());
            applicazione.choiceBoxMinuti.setValue((String)oin.readObject());
            applicazione.glicemiaInput.setText((String)oin.readObject());
            applicazione.insulinaInput.setText((String)oin.readObject());
            applicazione.choiceBoxEvento.setValue((String)oin.readObject());
            return true;
        }   catch(FileNotFoundException ex){
            System.err.println("Cache non trovata " + ex.getMessage());
        }   catch (IOException | ClassNotFoundException ex){
            System.err.println("Errore: impossibile prelevare da cache " + ex.getMessage());
        }
        return false;
    }

    
    public void salvaInCache(){ //04
        try(FileOutputStream fout = new FileOutputStream("file:../../cacheGestoreDiarioGUI.bin");
                ObjectOutputStream oout = new ObjectOutputStream(fout);
            ){
            if(applicazione.dataInput.getValue() == null &&     //05
            applicazione.choiceBoxOra.getValue() == null &&
            applicazione.choiceBoxMinuti.getValue() == null &&
            applicazione.glicemiaInput.getText().equals("-") &&
            applicazione.insulinaInput.getText().equals("0") &&
            applicazione.choiceBoxEvento.getValue() == null){
                oout.writeObject("");
                return;
            }
            oout.writeObject(applicazione.emailInput.getText());
            oout.writeObject(applicazione.daDatePicker.getValue());
            oout.writeObject(applicazione.aDatePicker.getValue());
            oout.writeObject(applicazione.dataInput.getValue());
            oout.writeObject(applicazione.choiceBoxOra.getValue());
            oout.writeObject(applicazione.choiceBoxMinuti.getValue());
            oout.writeObject(applicazione.glicemiaInput.getText());
            oout.writeObject(applicazione.insulinaInput.getText());
            oout.writeObject(applicazione.choiceBoxEvento.getValue());
        } catch (FileNotFoundException ex) {
            System.err.println("Errore cache non trovata " +ex.getMessage());
        } catch (IOException ex) {
            System.err.println("Errore impossibile scrivere su file: " +ex.getMessage());
        }
    }
}
/*
    01 La classe CacheGUI si occupa di gestire le azioni di letture/scrittura su file
    di cache binario e implementa due metodi uno per leggere da file, l'altro per 
    scrivere su file

    02 caricaDaCache si occupa di recupare il file di cache e di caricare gli oggetti
    nei rispettivi campi ed elementi

    03 Gli elementi vengo prelevati in come oggetti e poi convertiti tramite casting
    esplicito alle rispettive categorie 

    04 salvaInCache si occupa di prendere i valori degli elementi, se presenti, 
    dall'interfaccia grafica e di caricarli in formato binario su cache

    05 viene eseguito un controllo sugli elementi presenti sull'interfaccia grafica,
    se almeno uno di questi ha un valore diverso dal proprio valore di default, tutti
    i vari elementi vengono salvati per poi essere successivamente recuperati da 
    caricaDaCache. In caso contrario scrivo una stringa nulla sulla cache così da 
    sovrascrivere eventuali precedenti valori presenti e impedire che vengano ricaricati
    successivamente

*/