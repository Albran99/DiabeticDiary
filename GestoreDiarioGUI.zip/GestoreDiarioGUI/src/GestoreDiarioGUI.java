import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import javafx.application.Application;
import javafx.beans.Observable;
import javafx.collections.*;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Side;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 *
 * @author Fabio
 */
public class GestoreDiarioGUI extends Application {//01
    public Label emailLabel;
    public TextField emailInput;
    public Label daLabel;
    public DatePicker daDatePicker;
    public Label aLabel;
    public DatePicker aDatePicker;
    public Button mostraButton;
    public ObservableList<ReportDiabete> insiemeRecordDiabete;
    public TableView<ReportDiabete> tabellaReportDiabete;
    public DatePicker dataInput;
    public ChoiceBox choiceBoxOra;
    public ChoiceBox choiceBoxMinuti; 
    public TextField glicemiaInput;
    public TextField insulinaInput;
    public ChoiceBox choiceBoxEvento;
    public PieChart graficoTorta;
    public ObservableList<PieChart.Data> datiGraficoTorta;
    public Label mediaLabel;
    public TextField mediaText;
    public Label glicataLabel;
    public TextField glicataText;
    public Button cancellaButton;
    public Button inserisciButton;
    public ParametriConfigurazione parametriConfigurazione;
    public CacheGUI cacheGUI;
    public OperatoreXML operatoreXML;
    public OperatoreLog operatoreLog;
    public CollegamentoDBSM collegamentoDBSM;
    
    final VBox vboxMaster = new VBox();
    final HBox header = new HBox();
    final HBox datePicker_Mostra = new HBox();
    final HBox hboxInput = new HBox();
    final VBox mediaGlicata = new VBox();
    final HBox trailer = new HBox();
    final HBox cancellaInserisciBtn = new HBox();
    
    @Override
    public void start(Stage stage) {
        inizializzaGUI();
        if(cacheGUI.caricaDaCache())
            aggiornaTabella();
        stage.setTitle("Diario di gestione del diabete");
        Label titolo = new Label("Diario di gestione del diabete");
        titolo.setStyle("-fx-font-size: 20px; -fx-font-weight:bold;");
        //02
        datePicker_Mostra.getChildren().addAll(daLabel, daDatePicker, aLabel, aDatePicker, mostraButton);
        datePicker_Mostra.setAlignment(Pos.CENTER);
        datePicker_Mostra.setSpacing(10);
        
        header.getChildren().addAll(emailLabel, emailInput, datePicker_Mostra);
        header.setAlignment(Pos.CENTER);
        header.setSpacing(20);

        Label label = new Label(":");
        hboxInput.getChildren().addAll(dataInput, choiceBoxOra,label, choiceBoxMinuti, glicemiaInput, insulinaInput, choiceBoxEvento);
        
        HBox hboxMedia = new HBox(new Group(mediaLabel), mediaText);
        HBox hboxGlicata = new HBox(new Group(glicataLabel), glicataText);
        hboxMedia.setSpacing(15);
        hboxGlicata.setSpacing(15);
        
        mediaGlicata.getChildren().addAll(hboxMedia, hboxGlicata);
        mediaGlicata.setSpacing(10);
        
        trailer.getChildren().addAll(graficoTorta, mediaGlicata);
        trailer.setAlignment(Pos.CENTER);
        trailer.setSpacing(10);
        trailer.setPadding(new Insets(10,10,10,10));
        
        cancellaInserisciBtn.getChildren().addAll(cancellaButton, inserisciButton);
        cancellaInserisciBtn.setAlignment(Pos.BOTTOM_RIGHT);
        cancellaInserisciBtn.setSpacing(10);
        cancellaInserisciBtn.setPadding(new Insets(10,10,10,10));
        
        vboxMaster.getChildren().addAll(titolo, header, tabellaReportDiabete, hboxInput, trailer, cancellaInserisciBtn);
        vboxMaster.setAlignment(Pos.CENTER);
        vboxMaster.setSpacing(10);
        
        Scene scene = new Scene(vboxMaster, parametriConfigurazione.larghezza, parametriConfigurazione.altezza);
        scene.setFill(Color.valueOf(parametriConfigurazione.coloreSfondo));
        stage.setOnCloseRequest((WindowEvent we) -> {operatoreLog.inviaMessaggioDiLog("CHIUSURA"); cacheGUI.salvaInCache();});
        stage.setScene(scene);
        stage.show();
    }
    
    public void inizializzaGUI(){ //03
        parametriConfigurazione = new ParametriConfigurazione();
        collegamentoDBSM = new CollegamentoDBSM(this);
        operatoreLog = new OperatoreLog(this);
        cacheGUI = new CacheGUI(this);
        operatoreLog.inviaMessaggioDiLog("AVVIO");
        
        emailLabel = new Label("E-MAIL: ");
        
        emailInput = new TextField();
        emailInput.setAlignment(Pos.CENTER);
        
        daLabel = new Label("DA: ");
        
        daDatePicker = new DatePicker();
        daDatePicker.setPrefWidth(110);
        
        aLabel = new Label("A: ");
        
        aDatePicker = new DatePicker();
        aDatePicker.setPrefWidth(110);
        
        mostraButton = new Button("MOSTRA");
        mostraButton.setOnAction((ActionEvent evt)->{operatoreLog.inviaMessaggioDiLog("MOSTRA");aggiornaTabella();});
        
        mediaLabel = new Label("Media: ");
        
        mediaText = new TextField("-");
        mediaText.setEditable(false);
        mediaText.setMaxHeight(5);
        mediaText.setMaxWidth(70);
        
        glicataLabel = new Label("Glicata: ");
        glicataText = new TextField("-");
        glicataText.setEditable(false);
        glicataText.setMaxHeight(10);
        glicataText.setMaxWidth(70);
        
        cancellaButton = new Button("CANCELLA");     
        cancellaButton.setOnAction((ActionEvent evt)->{cancellaRiga();});
        
        inserisciButton = new Button("INSERISCI");
        inserisciButton.setOnAction((ActionEvent evt)->{inserisciRiga();});
        
        impostaTabella();
        impostaGraficoTorta();
        impostaRigaInput();
    }
    
    public void impostaGraficoTorta(){ //04
        datiGraficoTorta = FXCollections.observableArrayList(
                new PieChart.Data("Ipoglicemie Gravi", 50),
                new PieChart.Data("Ipoglicemie Leggere", 50),
                new PieChart.Data("Valori in Range", 50),
                new PieChart.Data("Iperglicemie Leggere", 50),
                new PieChart.Data("Iperglicemie Gravi", 50)
        );
        graficoTorta = new PieChart(datiGraficoTorta);
        graficoTorta.setLegendVisible(true);
        graficoTorta.setLabelsVisible(false);
        graficoTorta.setLegendSide(Side.LEFT);
    }
    
    public void impostaTabella(){ //05
        tabellaReportDiabete = new TableView<>(); 
        TableColumn<ReportDiabete, LocalDate> colonnaData = new TableColumn<>("DATA");
        colonnaData.setCellValueFactory(new PropertyValueFactory<>("data"));
        TableColumn<ReportDiabete, String> colonnaOra = new TableColumn<>("ORA");
        colonnaOra.setCellValueFactory(new PropertyValueFactory<>("ora"));
        TableColumn<ReportDiabete, Integer> colonnaGlicemia = new TableColumn<>("GLICEMIA");
        colonnaGlicemia.setCellValueFactory(new PropertyValueFactory<>("glicemia"));
        TableColumn<ReportDiabete, Integer> colonnaInsulina = new TableColumn<>("INSULINA");
        colonnaInsulina.setCellValueFactory(new PropertyValueFactory<>("insulina"));
        TableColumn<ReportDiabete, String> colonnaEvento = new TableColumn<>("EVENTO");
        colonnaEvento.setCellValueFactory(new PropertyValueFactory<>("evento"));
        
        tabellaReportDiabete.getColumns().addAll(colonnaData, colonnaOra, colonnaGlicemia, colonnaInsulina, colonnaEvento);
        tabellaReportDiabete.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        tabellaReportDiabete.setLayoutX(100);
        tabellaReportDiabete.setLayoutY(100);
        tabellaReportDiabete.getSelectionModel().selectedItemProperty().addListener(
                (evt) -> {operatoreLog.inviaMessaggioDiLog("SELEZIONE RIGA");}); //13
    }
    
    public void impostaRigaInput(){ //06
        dataInput = new DatePicker();
        
        choiceBoxOra = new ChoiceBox();
        for(int i = 0; i<24; ++i){
            choiceBoxOra.getItems().add(Integer.toString(i));
        }
        
        choiceBoxMinuti = new ChoiceBox();
        for(int i = 0; i<60; ++i){
            if(i<10){
                choiceBoxMinuti.getItems().add("0"+Integer.toString(i));  
            }
            else{
                choiceBoxMinuti.getItems().add(Integer.toString(i));
            }
        }
        
        glicemiaInput = new TextField("-");
        glicemiaInput.setMaxHeight(10);
        glicemiaInput.setAlignment(Pos.CENTER);
        
        insulinaInput = new TextField("0");
        insulinaInput.setMaxHeight(10);
        insulinaInput.setAlignment(Pos.CENTER);
        
        choiceBoxEvento = new ChoiceBox();
        choiceBoxEvento.getItems().add("Colazione");
        choiceBoxEvento.getItems().add("Pranzo");
        choiceBoxEvento.getItems().add("Cena");
        choiceBoxEvento.getItems().add("Spuntino");
        choiceBoxEvento.getItems().add("Controllo");
    }
    
    public void aggiornaGrafico(){ //07
        LocalDate da = (LocalDate)daDatePicker.getValue();
        LocalDate a = (LocalDate)aDatePicker.getValue();

        datiGraficoTorta.set(0, new PieChart.Data("Ipoglicemie Gravi", collegamentoDBSM.contaValoriInRange(
                        emailInput.getText(),
                        0, 
                        parametriConfigurazione.estremoIpoglicemiaGrave, 
                        da, a)) );
        datiGraficoTorta.set(1, new PieChart.Data("Ipoglicemie Leggere" , collegamentoDBSM.contaValoriInRange(
                        emailInput.getText(),
                        parametriConfigurazione.estremoIpoglicemiaGrave, 
                        parametriConfigurazione.estremoIpoglicemiaLeggera, 
                        da, a)));
        datiGraficoTorta.set(2, new PieChart.Data("Valori in range", collegamentoDBSM.contaValoriInRange(
                        emailInput.getText(),
                        parametriConfigurazione.estremoIpoglicemiaLeggera, 
                        parametriConfigurazione.estremoIperglicemiaLeggera, 
                        da, a)));
        datiGraficoTorta.set(3, new PieChart.Data("Iperglicemie Leggere", collegamentoDBSM.contaValoriInRange(
                        emailInput.getText(),
                        parametriConfigurazione.estremoIperglicemiaLeggera, 
                        parametriConfigurazione.estremoIperglicemiaGrave, 
                        da, a)));
        datiGraficoTorta.set(4,new PieChart.Data("Iperglicemie Gravi" , collegamentoDBSM.contaValoriInRange(
                        emailInput.getText(),
                        parametriConfigurazione.estremoIperglicemiaGrave, 
                        999, 
                        da, a)));
        int[] totale = {0};
        graficoTorta.getData().forEach((PieChart.Data dato) ->{
           totale[0] += dato.getPieValue();
        });
        graficoTorta.getData().forEach((PieChart.Data dato) ->{
            String percentuale = String.format("%.2f%%", (dato.getPieValue()/totale[0])*100);
            Tooltip toolTip = new Tooltip(percentuale);
            toolTip.install(dato.getNode(), toolTip);
        });
    }
    
    public void aggiornaTabella(){//08
        
        LocalDate da = (LocalDate)daDatePicker.getValue();
        LocalDate a = (LocalDate)aDatePicker.getValue();
        if(da == null || a == null){
            System.err.println("Errore: selezionare le gli estremi delle date");
            return;
        }
        if(emailInput.getText().equals("")){
            System.err.println("Errore: inserire una mail ");
            return;
        }
        List<ReportDiabete> test = collegamentoDBSM.queryReportDiabete(emailInput.getText(), da, a);
        insiemeRecordDiabete =  FXCollections.observableList(test);
        tabellaReportDiabete.setItems(insiemeRecordDiabete);
        
        aggiornaMedia();  
        aggiornaGrafico();
       


    }
    
    public void aggiornaMedia(){//09
       int[] mediaTotale = {0, 0};
        insiemeRecordDiabete.forEach((tab) -> { 
                mediaTotale[0] += tab.glicemia;
                mediaTotale[1]++;        
        });
        
        int media = mediaTotale[0]/mediaTotale[1];
        
        mediaText.setText(Integer.toString(media));
        calcolaGlicata(media);
    }
    
    public void calcolaGlicata(int media){ //10
        DecimalFormat formato = new DecimalFormat("#.0");
        double glicata = (46.7 + media)/28.7;
        glicataText.setText(formato.format(glicata) + "%");
        if(glicata>= parametriConfigurazione.medioInferioreGlicata && glicata<=parametriConfigurazione.medioSuperioreGlicata){
            glicataText.setStyle("-fx-background-color: green;");
        }else if((glicata>=parametriConfigurazione.estremoInferioreGlicata&& glicata<parametriConfigurazione.medioInferioreGlicata)
                    || (glicata>parametriConfigurazione.medioSuperioreGlicata && glicata<=parametriConfigurazione.estremoSuperioreGlicata))
            glicataText.setStyle("-fx-background-color: yellow;");
        else
            glicataText.setStyle("-fx-background-color: red;");
             
    }
    
    public void inserisciRiga(){ //11
        operatoreLog.inviaMessaggioDiLog("INSERISCI");
        if(glicemiaInput.getText().equals("-") || glicemiaInput.getText().equals("")){
            System.err.println("Inserire un valore numerico valido nel campo input di glicemia");
            return;
        }
        if(choiceBoxEvento.getValue() == null){
            System.err.println("selezionare un evento");
            return;
        }
        LocalDate data = (dataInput.getValue()==null)? LocalDate.now():(LocalDate)dataInput.getValue();
        String orario;
        String ora; 
        String minuti;
        if(choiceBoxOra.getValue() == null || choiceBoxMinuti.getValue() == null){
            ora = Integer.toString(LocalDateTime.now().getHour());
            minuti = Integer.toString(LocalDateTime.now().getMinute());
        }
        else{
            ora = (String) choiceBoxOra.getValue();
            minuti = (String) choiceBoxMinuti.getValue();
        }
        orario = ora + ":" + minuti;
        ReportDiabete repordDaInserire = new ReportDiabete(
                data,
                orario,
                Integer.parseInt(glicemiaInput.getText()),
                Integer.parseInt(insulinaInput.getText()),
                (String) choiceBoxEvento.getValue());
        if(!collegamentoDBSM.inserisciInDB(repordDaInserire, emailInput.getText())){
            System.err.println("errore nell'inserimento del nuovo report");
        }
        else{
            aggiornaTabella();
            dataInput.setValue(null);
            choiceBoxOra.setValue(null);
            choiceBoxMinuti.setValue(null);
            glicemiaInput.setText("-");
            insulinaInput.setText("0");
            choiceBoxEvento.setValue(null);
        }
    }
    
    public void cancellaRiga(){ //12
        operatoreLog.inviaMessaggioDiLog("CANCELLA");
        ReportDiabete reportDaCancellare = tabellaReportDiabete.getSelectionModel().getSelectedItem();
        if(reportDaCancellare == null){
            System.err.println("Selezionare una riga da cancellare");
            return;
        }
        if(!collegamentoDBSM.cancellaDaDB(reportDaCancellare, emailInput.getText())){
            System.err.println("errore nella cancellazione del nuovo report");
        }
        else{
            aggiornaTabella();
        }
    }
   
    
}


/*
    01 GestoreDiarioGUI è la classe principale dell'applicazione, si occupa di costruire
    l'interfaccia grafica, gestire le modifiche all'interfaccia a livello front-end,
    gestire gli eventi sull'interfaccia ed eventualmente eseguire chiamate alle 
    classi di back-end

    02 Gli elementi sono predisposti a schermo come una serie die VBox e HBox annidati,
    VboxMaster è il box che comprende tutti gli altri e che verra presentato sullo schermo
    all'avvio dell'aplicazione

    03 inizializzaGUI si occupa di iniziare gli elementi dell'interfaccia grafica e 
    di inizializzare gli oggetti di altre classi che serviranno durante il funzionamento
    dell'applicazione

    04 impostaGraficoTorta si occupa di inizializzare e di impostare il grafico a torta
    presente nell'interfaccia grafica. Il codice è stato separato da inizializzaGUI per
    garantire una maggiore leggibilita

    05 impostaTabella si occupa di inizializzare e di impostare la tabella dello storico
    delle misurazioni presente nell'interfaccia grafica. Il codice è stato separato da 
    inizializzaGUI per garantire una maggiore leggibilita.

    06 impostaRigaInput si occupa di inizializzare e di impostare la riga di input
    che si trova sotto la tabella principale. Il codice è stato separato da inizializzaGUI
    per garantire una maggiore leggibilita

    07 aggiornaGrafico si occupa di aggiornare gli elementi PieChart.Data del grafico a 
    torta ogni volta che viene effettuata una modifica alla tabella visualizzata. Il metodo
    viene invocato dalla aggiornaTabella.

    08 aggiornaTabella si occupa di aggiornare la tabella principale dell'intefaccia. 
    Il metodo è invocato ogni volta che viene premuto il tasto mostra oppure a seguito di
    un inserimento o cancellazione sul database. Il metodo chiama a sua volta aggionaGrafico 
    e aggiornaMedia per tenere aggiornate le informazioni di utilità mostrate a schermo

    09 aggiornaMedia si occupa di tenere aggiornato il campo di testo mediaText, ogni volta che 
    il metodo viene chiamato, viene ricalcolata la media in base ai dati presenti nella tabella
    principale. Il metodo chiama a sua volta aggiornaGlicata una volta finito di determinare il
    nuovo valore di media

    10 aggiornaGlicata si occupa di tenere aggiornato il campo di testo glicataText, ogni volta che 
    il metodo viene chiamato, viene ricalcolata la glicata in base al valore contenuto nel campo
    di media secondo la formula HbA1c(%) = (46.7 + AG(mg/dl))  / 28.7*. In base al valore calcolato
    il campo glicataText viene colorato di uno specifico colore, i limiti in base a cui vengono
    eseguiti i controlli si trovano nel file di configurazione XML
    
    *Dove AG: Avarage Glycemia e HbA1c: hemoglobin A1c

    11 inserisciRiga si occupa, alla pressione del pulsante INSERISCI di fare una richiesta
    a CollegamentoDBSM di inserire nel database un nuovo elemento di ReportDiabete. Il metodo
    imposta i campi di data e ora alla data e ora attuali qualora l'utente non li avesse già
    impostati.

    12 cancellaRiga si occupa di fare una richiesta a CollegamentoDBMS di cancellare dal database
    la riga selezionata sull'intefaccia grafica

    13 Questo listener genera ogni tanto in modo apparentenemente aleatorio un NullPointerException
    senza però bloccare il funzionamento dell'app, tutt'ora non ho ben capito cosa lo causi
*/