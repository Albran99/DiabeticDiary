
import java.io.*;
/**
 *
 * @author Fabio
 */
public class MessaggioDiLog implements Serializable{ //01
    public String nomeApplicazione;
    public String ipClient;
    public String timestamp;
    public String eventoDiLog;
    
    public MessaggioDiLog(String nomeApplicazione, String ipClient, String timestamp, String eventoDiLog){
        this.nomeApplicazione = nomeApplicazione;
        this.ipClient = ipClient;
        this.timestamp = timestamp;
        this.eventoDiLog = eventoDiLog;
    }
}
/*
    01 La classe MessaggioDiLog si occupa di fornire una forma ai messaggi di log
    da inviare al server cosi da poter poi essere inviati e scritti in formato XML
*/