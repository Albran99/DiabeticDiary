
import java.io.Serializable;
/**
 *
 * @author Fabio
 */
public class ParametriConfigurazione implements Serializable { //01
    public String ipClient;
    public String ipLogServer;
    public int portaLogServer;
    public String nomeDBSM;
    public String userDBSM;
    public String passwordDBSM;
    public String ipServerDBSM;
    public int portaServerDBSM;
    public double estremoInferioreGlicata;
    public double medioInferioreGlicata;
    public double medioSuperioreGlicata;
    public double estremoSuperioreGlicata;
    public int estremoIpoglicemiaGrave;
    public int estremoIpoglicemiaLeggera;
    public int estremoIperglicemiaLeggera;
    public int estremoIperglicemiaGrave;
    public String coloreSfondo;
    public int larghezza;
    public int altezza;
    public OperatoreXML operatoreXML;
    
    public ParametriConfigurazione(){ 
        operatoreXML = new OperatoreXML();
        if(operatoreXML.validaXML()){
            ParametriConfigurazione tmp = operatoreXML.estraiParametriConfigurazione(); //02
            this.ipClient = tmp.ipClient;
            this.ipLogServer = tmp.ipLogServer;
            this.portaLogServer = tmp.portaLogServer;
            this.nomeDBSM= tmp.nomeDBSM;
            this.userDBSM = tmp.userDBSM;
            this.passwordDBSM = tmp.passwordDBSM;
            this.ipServerDBSM = tmp.ipServerDBSM;
            this.portaServerDBSM = tmp.portaServerDBSM;
            this.estremoInferioreGlicata = tmp.estremoInferioreGlicata;
            this.medioInferioreGlicata = tmp.medioInferioreGlicata;
            this.medioSuperioreGlicata = tmp.medioSuperioreGlicata;
            this.estremoSuperioreGlicata = tmp.estremoSuperioreGlicata;
            this.estremoIpoglicemiaGrave = tmp.estremoIpoglicemiaGrave;
            this.estremoIpoglicemiaLeggera = tmp.estremoIpoglicemiaLeggera;
            this.estremoIperglicemiaLeggera = tmp.estremoIperglicemiaLeggera;
            this.estremoIperglicemiaGrave = tmp.estremoIperglicemiaGrave;
            this.coloreSfondo = tmp.coloreSfondo;
            this.larghezza = tmp.larghezza;
            this.altezza = tmp.altezza;
        }
    }
}

/*
    01 ParametriConfigurazione si occupa di mettere a disposizione tutti i valori
    di configurazione dopo che sono stati estratti da file di configurazione 

    02  estraiParametriConfigurazione ritornerà un oggetto di tipo 
    ParametriConfigurazione, così è possibile accederci ai campi e usarli
    per impostare i valori di quest'oggetto usato dalla classe GestoreDiarioGUI

*/