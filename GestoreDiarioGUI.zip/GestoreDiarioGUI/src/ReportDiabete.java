import java.time.LocalDate;

/**
 *
 * @author Fabio
 */
public class ReportDiabete { //01
    public LocalDate data;
    public String ora;
    public int glicemia;
    public int insulina;
    public String evento;
    
    public ReportDiabete(LocalDate data, String ora, int glicemia, int insulina, String evento){
        this.data = data;
        this.ora = ora;
        this.glicemia = glicemia;
        this.insulina = insulina;
        this.evento = evento;
    }
    
    public LocalDate getData(){
        return data;
    }
    
    public void setData(LocalDate data){
        this.data = data;
    }
    
    public String getOra(){
        return ora;
    }
    
    public void setOra(String ora){
        this.ora = ora;
    }
    
    public int getGlicemia(){
        return glicemia;
    }
    
    public void setOra(int glicemia){
        this.glicemia = glicemia;
    }
    
    public int getInsulina(){
        return insulina;
    }
    
    public void setInsulina(int insulina){
        this.insulina = insulina;
    }
    
    public String getEvento(){
        return evento;
    }
    
    public void setEvento(String evento){
        this.evento = evento;
    }
}
/*
    01 ReportDiabete è la classe Bean che si occupa di dare una struttura a un insieme
    di dati così da poter manipolare direttamente l'oggetto complesso per le operazioni
    di inserimento/cancellazione su database
*/