import com.thoughtworks.xstream.XStream;
import java.io.*;
import java.nio.file.*;
import javax.xml.XMLConstants;
import javax.xml.parsers.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;

/**
 *
 * @author Fabio
 */
public class OperatoreXML { //01
   
    public boolean validaXML(){ //02
        try {   
            DocumentBuilder db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Document d = db.parse(new File("ParametriConfigurazione.xml")); 
            Schema s = sf.newSchema(new StreamSource(new File("ParametriConfigurazione.xsd")));
            s.newValidator().validate(new DOMSource(d));
            return true;
            } catch (Exception e) {
                if (e instanceof SAXException) 
                    System.out.println("Errore di validazione: " + e.getMessage());
                else
                    System.out.println(e.getMessage()); 
                return false;
            }

    }
    
    public ParametriConfigurazione estraiParametriConfigurazione(){ //03
        ParametriConfigurazione contenutoFileXML;
        try{
            String x = new String(Files.readAllBytes(Paths.get("ParametriConfigurazione.xml")));
            XStream xs = new XStream();
            contenutoFileXML = (ParametriConfigurazione)xs.fromXML(x); 

        } catch (IOException e) {
            System.out.println("Problema nell'estrazione del file di configurazione: " + e.getMessage());
            return null;
        }
        return contenutoFileXML;

    }
    
    public String serializzaMessaggioXML(MessaggioDiLog messaggio){ //04
        XStream xs = new XStream();
        return xs.toXML(messaggio);

    }
    
}

/*
    01 OperatoreXML si occupa di fornire diversi metodi di utilità per validare 
    file ed estrarre il contenuto da file XML e di serializzare in formato XML 
    oggetti di tipo MessaggioDiLog

    02 validaXML si occupa di validare il contenuto di un file XML tramite file
    XSD, se la validazione ha successo il metodo ritorna true, false altrimenti

    03 estraiParametriConfigurazione si occupa di estrarre il contenuto da file
    XML e di convertirlo tramite casting esplicito in un oggetto di classe
    ParametriConfigurazione. Il metodo ritorna un elemento ParametriConfigurazione
    se ha successo nell'estrazione, ritorna null altrimenti

    04 serializzaMessaggioXML si occupa di generare e ritornare una stringa XML
    partendo da un oggetto di classe MessaggioDiLog passatogli in ingresso

*/