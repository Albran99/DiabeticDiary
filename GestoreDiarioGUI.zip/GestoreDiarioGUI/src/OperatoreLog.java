
import java.io.*;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Fabio
 */
public class OperatoreLog { //01
    public GestoreDiarioGUI applicazione;
    public OperatoreXML operatoreXML;
    public MessaggioDiLog messaggioDiLog;
    
    public OperatoreLog(GestoreDiarioGUI applicazione){
        this.applicazione = applicazione;
    }
    
    public void inviaMessaggioDiLog(String evento){ //02
        try(
                Socket socket = new Socket(applicazione.parametriConfigurazione.ipLogServer,
                                            applicazione.parametriConfigurazione.portaLogServer);
                DataOutputStream dout = new DataOutputStream(socket.getOutputStream())
        )
        {
            SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
            Date date = new Date(System.currentTimeMillis());
            operatoreXML = new OperatoreXML(); //03
            messaggioDiLog = new MessaggioDiLog(
                    "Diario di gestione del diabete", 
                    applicazione.parametriConfigurazione.ipClient,
                    formatter.format(date),
                    evento); //03
            dout.writeUTF(operatoreXML.serializzaMessaggioXML(messaggioDiLog));
        }catch(IOException ex){
            System.err.println("Errore in fase di creazione del socket"
                        + " e di gestione del flusso " + ex.getMessage());
        } 
    }
}
/*
    01 OperatoreLog si occupa di inviare al server di log un messaggio ogni
    volta che il suo metodo inviaMessaggioDiLog viene invocato da GestoreDiarioGUI
    al verificarsi di particolari eventi

    02 inviaMessaggioDiLog si occupa di inviare tramite socket un messaggio di log
    al server in ascolto. Il metodo prende in ingresso il tipo di evento sotto forma
    di stringa

    03 Vengono creati due oggetti, rispettivamente: il messaggio di log da inviare
    e l'operatoreXML che serve per serializzare il messaggio di log in formato XML
*/