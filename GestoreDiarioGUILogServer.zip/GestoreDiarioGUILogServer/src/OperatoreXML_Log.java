
import java.io.*;
import java.nio.file.*;
import javax.xml.*;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.*;
import org.xml.sax.SAXException;
/**
 *
 * @author Fabio
 */
public class OperatoreXML_Log { //01
    
    public boolean validaXML(String testoXML){ //02
        try {   
            SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
            Schema schema = sf.newSchema(new StreamSource(new File("MessaggioDiLog.xsd"))); 
            Validator validator = schema.newValidator();
            Source source = new StreamSource(new StringReader(testoXML));
            validator.validate(source);
            } catch (SAXException | IOException ex) {
                if (ex instanceof SAXException) 
                    System.err.println("Errore di validazione: " + ex.getMessage());
                else
                    System.err.println("Errore nella lettura dei file: " + ex.getMessage()); 
                return false;
            }
        return true;
    }
    
    public void scriviSuFileDiTesto(String testoXML){ //03
        try{
            File log = new File("log.txt");
            Files.write(log.toPath(), testoXML.getBytes(), StandardOpenOption.APPEND);
        } catch (IOException ex) {
            System.err.println("impossibile scrivere su file di log " + ex.getMessage());
        }
    }
}

/*
    01 La classe OperatoreLog_XML si occupa di mettere a disposizione dei metodi di utilità per
    la classe LogServer

    02 validaXML prende in ingresso una stringa di testo XML ed esegue la validazione tramite file 
    esterno XSD ritorna true se l'operazione ha successo, false altrimeti

    03 scriviSuFileDiTesto prende in ingresso una stringa di testo XML e la scrive sul file di testo
    log.txt. La scrittura avviene in APPEND così da non sovrascrivere i log precedenti
*/