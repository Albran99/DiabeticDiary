

import java.io.*;
import java.net.*;

/**
 *
 * @author Fabio
 */
public class LogServer {    //01
    
    public static OperatoreXML_Log operatoreXML_Log;
    
    public static void main(String[] args) {
        operatoreXML_Log = new OperatoreXML_Log();
        do{
            try ( ServerSocket servs = new ServerSocket(8080);
              Socket sd = servs.accept(); 
              DataInputStream din = new DataInputStream(sd.getInputStream());
            ) 
            {
                String testoXML = din.readUTF();
                testoXML = testoXML + "\n";
                if(operatoreXML_Log.validaXML(testoXML)){
                    operatoreXML_Log.scriviSuFileDiTesto(testoXML);
                }else{
                    System.err.println("Errore nel validare il messaggio di log ricevuto");
                }
            }catch (IOException ex) {System.err.println(ex.getMessage());}
        }while(true);
    }
}

/*
    01 La classe Log server si occupa di ricevere tramite socket il messaggio di Log
    inviatogli da operatoreLog. Si appoggia su due metodi di utilità implementati da
    OperatoreXML_Log che gli permettono di validare il testo XML ricevuto e di scrivelo
    su file di log (log.txt)
*/
    

